/*
 * Manual QA checklists — shared behaviour.
 *
 * Each page marks up test cases as <article class="tc" id="XX-000" data-priority="P1|P2|P3">.
 * This script adds Pass / Fail / Blocked / N/A buttons and a notes box to every case,
 * a sticky toolbar with progress, filters and export, and tester details at the top.
 * Results live in this browser's localStorage only; export to share them.
 */
(function () {
  'use strict';

  var PAGES = [
    ['01-setup.html', 'Setup, install & configuration'],
    ['02-database-schema.html', 'Database schema & migrations'],
    ['03-content.html', 'Content: collections, documents, publishing'],
    ['04-admin-ui.html', 'Admin UI & navigation'],
    ['05-auth-security.html', 'Authentication, users, roles & security'],
    ['06-media-seo.html', 'Media, SEO & structured data'],
    ['07-forms-email-marketing.html', 'Forms, email, newsletter, popups, cookies'],
    ['08-commerce.html', 'Commerce: shop, checkout, orders'],
    ['09-booking.html', 'Booking: availability & reservations'],
    ['10-settings-cron-ops.html', 'Settings, scheduled jobs & operations'],
    ['11-public-site.html', 'Public site, languages, accessibility & performance'],
  ];
  var STATUSES = [
    ['pass', 'Pass'],
    ['fail', 'Fail'],
    ['blocked', 'Blocked'],
    ['na', 'N/A'],
  ];

  function store() {
    try {
      var k = '__qa_probe__';
      window.localStorage.setItem(k, '1');
      window.localStorage.removeItem(k);
      return window.localStorage;
    } catch {
      return null;
    }
  }
  var ls = store();
  function get(key, fallback) {
    if (!ls) return fallback;
    try {
      var v = ls.getItem(key);
      return v === null ? fallback : JSON.parse(v);
    } catch {
      return fallback;
    }
  }
  function set(key, value) {
    if (!ls) return;
    try {
      ls.setItem(key, JSON.stringify(value));
    } catch {
      /* storage full or blocked — results just won't persist */
    }
  }

  var page = (location.pathname.split('/').pop() || 'index.html').replace(/\.html$/, '');
  var resultKey = 'qa:results:' + page;
  var totalKey = 'qa:total:' + page;
  var metaKey = 'qa:meta';

  function el(tag, attrs, children) {
    var n = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (a) {
        if (a === 'text') n.textContent = attrs[a];
        else n.setAttribute(a, attrs[a]);
      });
    }
    (children || []).forEach(function (c) {
      n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return n;
  }

  function download(name, type, body) {
    var blob = new Blob([body], { type: type });
    var a = el('a', { href: URL.createObjectURL(blob), download: name });
    document.body.appendChild(a);
    a.click();
    setTimeout(function () {
      URL.revokeObjectURL(a.href);
      a.remove();
    }, 0);
  }

  function csvCell(v) {
    var s = String(v == null ? '' : v);
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  /* ---------- Tester details (shared across pages) ---------- */
  function metaPanel() {
    var meta = get(metaKey, {});
    var fields = [
      ['tester', 'Tester'],
      ['env', 'Environment URL'],
      ['build', 'Build / commit'],
      ['date', 'Test date'],
    ];
    var wrap = el('div', { class: 'qa-meta' });
    fields.forEach(function (f) {
      var input = el('input', { type: f[0] === 'date' ? 'date' : 'text', value: meta[f[0]] || '' });
      input.addEventListener('input', function () {
        meta[f[0]] = input.value;
        set(metaKey, meta);
      });
      wrap.appendChild(el('label', null, [f[1], input]));
    });
    return wrap;
  }

  /* ---------- Index page: progress across all pages ---------- */
  function renderIndex() {
    var host = document.getElementById('qa-index');
    if (!host) return;
    var rows = PAGES.map(function (p) {
      var id = p[0].replace(/\.html$/, '');
      var res = get('qa:results:' + id, {});
      var total = get('qa:total:' + id, null);
      var c = { pass: 0, fail: 0, blocked: 0, na: 0 };
      Object.keys(res).forEach(function (k) {
        if (res[k] && c[res[k].status] !== undefined) c[res[k].status]++;
      });
      var done = c.pass + c.fail + c.blocked + c.na;
      return el('tr', null, [
        el('td', null, [el('a', { href: p[0], text: p[1] })]),
        el('td', { text: total == null ? '—' : String(total) }),
        el('td', { text: String(done) }),
        el('td', { text: String(c.pass) }),
        el('td', { text: String(c.fail) }),
        el('td', { text: String(c.blocked) }),
      ]);
    });
    var table = el('table', null, [
      el('thead', null, [
        el('tr', null, ['Checklist', 'Cases', 'Run', 'Pass', 'Fail', 'Blocked'].map(function (h) {
          return el('th', { text: h });
        })),
      ]),
      el('tbody', null, rows),
    ]);
    host.appendChild(el('div', { class: 'table-wrap' }, [table]));
    var note = el('p', {
      class: 'note',
      text: ls
        ? 'Counts come from this browser. "Cases" appears once a checklist has been opened here.'
        : 'This browser is blocking local storage, so results cannot be saved or totalled. Use Export on each page.',
    });
    host.appendChild(note);
    var header = document.querySelector('header.page');
    if (header) header.appendChild(metaPanel());
  }

  /* ---------- Checklist pages ---------- */
  function renderChecklist(cases) {
    var results = get(resultKey, {});
    set(totalKey, cases.length);

    function save() {
      set(resultKey, results);
      refresh();
    }

    cases.forEach(function (tc) {
      var id = tc.id;
      var h3 = tc.querySelector('h3');
      if (h3 && !h3.querySelector('.tc-id')) {
        h3.insertBefore(el('span', { class: 'tc-id', text: id }), h3.firstChild);
        var prio = tc.getAttribute('data-priority');
        if (prio) h3.appendChild(el('span', { class: 'tc-prio ' + prio, text: prio }));
      }
      var r = results[id] || {};
      var controls = el('div', { class: 'tc-controls', role: 'group', 'aria-label': 'Result for ' + id });
      var buttons = STATUSES.map(function (s) {
        var b = el('button', { type: 'button', class: 'st ' + s[0], 'aria-pressed': String(r.status === s[0]), text: s[1] });
        b.addEventListener('click', function () {
          var cur = results[id] || {};
          cur.status = cur.status === s[0] ? undefined : s[0];
          cur.at = new Date().toISOString();
          results[id] = cur;
          buttons.forEach(function (x, i) {
            x.setAttribute('aria-pressed', String(cur.status === STATUSES[i][0]));
          });
          if (cur.status) tc.setAttribute('data-status', cur.status);
          else tc.removeAttribute('data-status');
          save();
        });
        controls.appendChild(b);
        return b;
      });
      var notes = el('textarea', { rows: '1', placeholder: 'Notes, defect ID, screenshot link…', 'aria-label': 'Notes for ' + id });
      notes.value = r.notes || '';
      notes.addEventListener('input', function () {
        var cur = results[id] || {};
        cur.notes = notes.value;
        results[id] = cur;
        set(resultKey, results);
      });
      controls.appendChild(notes);
      tc.appendChild(controls);
      if (r.status) tc.setAttribute('data-status', r.status);
    });

    /* Toolbar */
    var bar = el('div', { class: 'qa-bar' });
    var counts = el('div', { class: 'qa-counts' });
    var search = el('input', { type: 'search', placeholder: 'Filter by text or ID', 'aria-label': 'Filter test cases' });
    var statusSel = el('select', { 'aria-label': 'Filter by result' }, [
      el('option', { value: '', text: 'All results' }),
      el('option', { value: 'todo', text: 'Not run' }),
      el('option', { value: 'pass', text: 'Pass' }),
      el('option', { value: 'fail', text: 'Fail' }),
      el('option', { value: 'blocked', text: 'Blocked' }),
      el('option', { value: 'na', text: 'N/A' }),
    ]);
    var prioSel = el('select', { 'aria-label': 'Filter by priority' }, [
      el('option', { value: '', text: 'All priorities' }),
      el('option', { value: 'P1', text: 'P1 — smoke' }),
      el('option', { value: 'P2', text: 'P2 — core' }),
      el('option', { value: 'P3', text: 'P3 — edge' }),
    ]);
    var csvBtn = el('button', { type: 'button', text: 'Export CSV' });
    var jsonBtn = el('button', { type: 'button', text: 'Export JSON' });
    var resetBtn = el('button', { type: 'button', text: 'Reset page' });

    var toolbar = el('div', { class: 'qa-toolbar' }, [
      el('div', { class: 'row' }, [el('div', { class: 'qa-progress' }, [bar, counts])]),
      el('div', { class: 'row' }, [search, statusSel, prioSel, csvBtn, jsonBtn, resetBtn]),
    ]);
    var header = document.querySelector('header.page');
    header.appendChild(metaPanel());
    header.parentNode.insertBefore(toolbar, header.nextSibling);

    function applyFilters() {
      var q = search.value.trim().toLowerCase();
      var st = statusSel.value;
      var pr = prioSel.value;
      cases.forEach(function (tc) {
        var r = results[tc.id] || {};
        var show = true;
        if (q && tc.textContent.toLowerCase().indexOf(q) === -1) show = false;
        if (st === 'todo' && r.status) show = false;
        if (st && st !== 'todo' && r.status !== st) show = false;
        if (pr && tc.getAttribute('data-priority') !== pr) show = false;
        tc.classList.toggle('hidden', !show);
      });
      document.querySelectorAll('section.suite').forEach(function (s) {
        var any = s.querySelector('article.tc:not(.hidden)');
        s.classList.toggle('hidden', !any);
      });
    }
    [search, statusSel, prioSel].forEach(function (c) {
      c.addEventListener('input', applyFilters);
    });

    function refresh() {
      var c = { pass: 0, fail: 0, blocked: 0, na: 0 };
      cases.forEach(function (tc) {
        var s = (results[tc.id] || {}).status;
        if (s) c[s]++;
      });
      var total = cases.length || 1;
      bar.textContent = '';
      [['p', c.pass], ['f', c.fail], ['b', c.blocked], ['n', c.na]].forEach(function (x) {
        if (x[1]) bar.appendChild(el('span', { class: x[0], style: 'width:' + (100 * x[1]) / total + '%' }));
      });
      var run = c.pass + c.fail + c.blocked + c.na;
      counts.textContent =
        run + ' of ' + cases.length + ' run · ' + c.pass + ' pass · ' + c.fail + ' fail · ' + c.blocked + ' blocked · ' + c.na + ' N/A';
      applyFilters();
    }

    function rows() {
      var meta = get(metaKey, {});
      return cases.map(function (tc) {
        var r = results[tc.id] || {};
        var h = tc.querySelector('h3');
        var title = h ? h.textContent.replace(tc.id, '').replace(/P[123]$/, '').trim() : '';
        var suite = tc.closest('section.suite');
        var suiteTitle = suite && suite.querySelector('h2') ? suite.querySelector('h2').textContent.trim() : '';
        return {
          page: page,
          suite: suiteTitle,
          id: tc.id,
          priority: tc.getAttribute('data-priority') || '',
          title: title,
          status: r.status || 'not run',
          notes: r.notes || '',
          updated: r.at || '',
          tester: meta.tester || '',
          environment: meta.env || '',
          build: meta.build || '',
        };
      });
    }
    csvBtn.addEventListener('click', function () {
      var data = rows();
      var cols = Object.keys(data[0] || { id: '' });
      var body = [cols.join(',')].concat(data.map(function (r) {
        return cols.map(function (c) { return csvCell(r[c]); }).join(',');
      })).join('\n');
      download('qa-' + page + '.csv', 'text/csv', body);
    });
    jsonBtn.addEventListener('click', function () {
      download('qa-' + page + '.json', 'application/json', JSON.stringify({ meta: get(metaKey, {}), results: rows() }, null, 2));
    });
    resetBtn.addEventListener('click', function () {
      if (!window.confirm('Clear every result and note on this page?')) return;
      results = {};
      set(resultKey, results);
      location.reload();
    });

    refresh();
  }

  document.addEventListener('DOMContentLoaded', function () {
    var cases = Array.prototype.slice.call(document.querySelectorAll('article.tc[id]'));
    if (cases.length) renderChecklist(cases);
    else renderIndex();
  });
})();
